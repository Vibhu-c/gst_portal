import pandas as pd
from datetime import date, datetime
from random import randint
from typing import Optional


def calculate_row_tax(turnover: float, purchase_value: float, gst_rate: float, is_inter_state: int):
    output_tax = turnover * (gst_rate / 100)
    input_tax = purchase_value * (gst_rate / 100)

    if is_inter_state:
        igst = output_tax
        cgst = 0.0
        sgst = 0.0
    else:
        cgst = output_tax / 2
        sgst = output_tax / 2
        igst = 0.0

    return {
        "output_tax": round(output_tax, 2),
        "input_tax": round(input_tax, 2),
        "cgst": round(cgst, 2),
        "sgst": round(sgst, 2),
        "igst": round(igst, 2),
    }


def build_return_dataframe(rows):
    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame([dict(r) for r in rows])

    tax_cols = df.apply(
        lambda r: calculate_row_tax(r["turnover"], r["purchase_value"], r["gst_rate"], r["is_inter_state"]),
        axis=1,
        result_type="expand",
    )
    df = pd.concat([df, tax_cols], axis=1)

    df["net_tax_payable"] = (
        df["output_tax"] - df["itc_claimed"] - df["tds_received"] - df["tcs_received"]
    ).round(2)
    df["net_tax_payable"] = df["net_tax_payable"].clip(lower=0.0)

    return df


def get_year_summary(df: pd.DataFrame):
    if df.empty:
        return {
            "turnover": 0.0,
            "purchases": 0.0,
            "output_tax": 0.0,
            "itc_claimed": 0.0,
            "tds_tcs_credit": 0.0,
            "net_tax_payable": 0.0,
        }

    return {
        "turnover": round(float(df["turnover"].sum()), 2),
        "purchases": round(float(df["purchase_value"].sum()), 2),
        "output_tax": round(float(df["output_tax"].sum()), 2),
        "itc_claimed": round(float(df["itc_claimed"].sum()), 2),
        "tds_tcs_credit": round(float(df["tds_received"].sum() + df["tcs_received"].sum()), 2),
        "net_tax_payable": round(float(df["net_tax_payable"].sum()), 2),
    }


def smart_insights(df: pd.DataFrame):
    insights = []
    if df.empty:
        return ["No records yet. Add at least one monthly entry to generate smart insights."]

    missing_returns = df[
        (df["gstr1_reported"] == 0) | (df["gstr3b_reported"] == 0) | (df["gstr2a_reported"] == 0)
    ]
    if not missing_returns.empty:
        insights.append(
            f"{len(missing_returns)} month(s) have incomplete return filing flags (GSTR-1/GSTR-3B/GSTR-2A)."
        )

    high_itc = df[df["itc_claimed"] > (df["output_tax"] * 0.9)]
    if not high_itc.empty:
        insights.append(
            f"{len(high_itc)} month(s) show ITC claims above 90% of output tax. Review supporting invoices."
        )

    low_tax = df[df["net_tax_payable"] < (df["output_tax"] * 0.1)]
    if not low_tax.empty:
        insights.append(
            f"{len(low_tax)} month(s) have net GST payable below 10% of output tax after credits."
        )

    if len(df) >= 3:
        avg_last_3 = df.sort_values("month")["net_tax_payable"].tail(3).mean()
        insights.append(
            f"Predicted next-month GST payable (simple moving average): Rs. {avg_last_3:,.2f}"
        )

    if not insights:
        insights.append("Compliance appears healthy for current records.")

    return insights


def build_compliance_snapshot(df: pd.DataFrame, invoice_df: pd.DataFrame):
    snapshot = {
        "score": 100,
        "status": "Excellent",
        "pending_returns": 0,
        "risky_periods": 0,
        "duplicate_invoices": 0,
        "invoice_gstin_gaps": 0,
        "forecast_tax": 0.0,
        "alerts": [],
        "recommendations": [],
    }

    if df.empty:
        snapshot["score"] = 0
        snapshot["status"] = "No Filing Data"
        snapshot["alerts"].append("No GST return history is available yet for compliance evaluation.")
        snapshot["recommendations"].append("Prepare at least one return period to activate smart compliance tracking.")
        return snapshot

    pending_mask = (df["gstr1_reported"] == 0) | (df["gstr3b_reported"] == 0) | (df["gstr2a_reported"] == 0)
    pending_returns = int(pending_mask.sum())
    snapshot["pending_returns"] = pending_returns
    if pending_returns:
        snapshot["score"] -= min(40, pending_returns * 8)
        snapshot["alerts"].append(
            f"{pending_returns} period(s) are missing one or more return confirmations across GSTR-1, GSTR-3B or GSTR-2A."
        )
        snapshot["recommendations"].append("Close pending filing flags first to improve compliance health.")

    risky_periods = int((df["itc_claimed"] > (df["output_tax"] * 0.85)).sum() + (df["net_tax_payable"] < (df["output_tax"] * 0.1)).sum())
    snapshot["risky_periods"] = risky_periods
    if risky_periods:
        snapshot["score"] -= min(20, risky_periods * 4)
        snapshot["alerts"].append(
            "Credit utilization pattern is aggressive in one or more periods. Review ITC support and output-tax offsets."
        )
        snapshot["recommendations"].append("Reconcile ITC-ledger values with supporting invoices before final filing.")

    if len(df.index) >= 3:
        sorted_df = df.copy()
        if "month" in sorted_df.columns:
            sorted_df = sorted_df.sort_values("month")
        forecast_tax = float(sorted_df["net_tax_payable"].tail(3).mean())
    else:
        forecast_tax = float(df["net_tax_payable"].mean())
    snapshot["forecast_tax"] = round(forecast_tax, 2)

    if not invoice_df.empty:
        duplicate_invoices = int(invoice_df.duplicated(subset=["invoice_no"], keep=False).sum())
        snapshot["duplicate_invoices"] = duplicate_invoices
        if duplicate_invoices:
            snapshot["score"] -= min(20, duplicate_invoices * 3)
            snapshot["alerts"].append(
                f"{duplicate_invoices} invoice row(s) share duplicate invoice numbers. This may create reconciliation issues."
            )
            snapshot["recommendations"].append("Review duplicate invoice numbers before preparing GSTR-1.")

        gstin_gaps = int(invoice_df["counterparty_gstin"].fillna("").astype(str).str.strip().eq("").sum())
        snapshot["invoice_gstin_gaps"] = gstin_gaps
        if gstin_gaps:
            snapshot["score"] -= min(15, gstin_gaps * 2)
            snapshot["alerts"].append(
                f"{gstin_gaps} invoice row(s) are missing seller or buyer GSTIN details needed for cleaner compliance records."
            )
            snapshot["recommendations"].append("Capture missing GSTIN values in invoice entry to strengthen audit readiness.")

        if "taxable_value" in invoice_df.columns and len(invoice_df.index) >= 5:
            high_value_threshold = float(invoice_df["taxable_value"].quantile(0.9))
            high_value_count = int((invoice_df["taxable_value"] >= high_value_threshold).sum())
            snapshot["alerts"].append(
                f"{high_value_count} high-value invoice(s) fall in the top 10% bracket and should be reviewed before submission."
            )
            snapshot["recommendations"].append("Use invoice-level review for high-value transactions before generating GSTR-3B.")

    snapshot["score"] = max(0, min(100, int(round(snapshot["score"]))))

    if snapshot["score"] >= 85:
        snapshot["status"] = "Excellent"
    elif snapshot["score"] >= 70:
        snapshot["status"] = "Good"
    elif snapshot["score"] >= 50:
        snapshot["status"] = "Watchlist"
    else:
        snapshot["status"] = "High Risk"

    if not snapshot["alerts"]:
        snapshot["alerts"].append("No major compliance anomaly is detected in the current filing data.")
    if not snapshot["recommendations"]:
        snapshot["recommendations"].append("Continue monthly or quarterly reconciliation to maintain a strong compliance score.")

    return snapshot


def _fy_start_year(financial_year: str):
    try:
        parts = financial_year.replace("FY", "").strip().split("-")
        return int(parts[0])
    except (ValueError, IndexError, AttributeError):
        return datetime.now().year


def _period_end_month(period: str, filing_frequency: str):
    monthly_map = {
        "Apr": 4,
        "May": 5,
        "Jun": 6,
        "Jul": 7,
        "Aug": 8,
        "Sep": 9,
        "Oct": 10,
        "Nov": 11,
        "Dec": 12,
        "Jan": 1,
        "Feb": 2,
        "Mar": 3,
    }
    quarterly_map = {
        "Q1 (Apr-Jun)": 6,
        "Q2 (Jul-Sep)": 9,
        "Q3 (Oct-Dec)": 12,
        "Q4 (Jan-Mar)": 3,
    }
    if filing_frequency == "Quarterly":
        return quarterly_map.get(period)
    return monthly_map.get(period)


def _month_year_for_period(financial_year: str, period: str, filing_frequency: str):
    end_month = _period_end_month(period, filing_frequency)
    start_year = _fy_start_year(financial_year)
    if end_month is None:
        return start_year, 4
    year = start_year if end_month >= 4 else start_year + 1
    return year, end_month


def build_due_date_calendar(financial_year: str, filing_frequency: str, period: str):
    year, end_month = _month_year_for_period(financial_year, period, filing_frequency)
    if filing_frequency == "Quarterly":
        gstr1_due = date(year, end_month, 13)
        gstr3b_due = date(year, end_month, 22)
    else:
        next_month = 1 if end_month == 12 else end_month + 1
        next_year = year + 1 if end_month == 12 else year
        gstr1_due = date(next_year, next_month, 11)
        gstr3b_due = date(next_year, next_month, 20)

    return {
        "gstr1_due": gstr1_due,
        "gstr3b_due": gstr3b_due,
        "itc_reco_due": gstr3b_due,
    }


def estimate_late_fee(financial_year: str, filing_frequency: str, period: str, filed_at: Optional[str] = None):
    due_dates = build_due_date_calendar(financial_year, filing_frequency, period)
    gstr3b_due = due_dates["gstr3b_due"]

    if filed_at:
        try:
            filing_date = datetime.strptime(filed_at, "%Y-%m-%d %H:%M:%S").date()
        except ValueError:
            filing_date = date.today()
    else:
        filing_date = date.today()

    delay_days = max((filing_date - gstr3b_due).days, 0)
    estimated_fee = min(delay_days * 50, 10000)
    return {
        "delay_days": delay_days,
        "estimated_fee": float(estimated_fee),
        "due_date": gstr3b_due,
        "filing_date": filing_date,
    }


def build_notice_center(df: pd.DataFrame, invoice_df: pd.DataFrame, financial_year: str, filing_frequency: str):
    notices = []

    if df.empty:
        notices.append(
            {
                "priority": "High",
                "notice_type": "Registration Alert",
                "message": "No return preparation data exists yet for the selected year. Compliance monitoring is inactive.",
                "recommended_action": "Prepare the first GST period to activate compliance controls.",
            }
        )
        return notices

    for _, row in df.iterrows():
        period = row.get("month", "")
        due_dates = build_due_date_calendar(financial_year, filing_frequency, period)
        if row.get("gstr1_reported", 0) == 0:
            notices.append(
                {
                    "priority": "High",
                    "notice_type": "GSTR-1 Pending",
                    "message": f"GSTR-1 appears pending for {period}. Due date reference is {due_dates['gstr1_due'].strftime('%d %b %Y')}.",
                    "recommended_action": "Complete invoice review and mark GSTR-1 prepared before filing.",
                }
            )
        if row.get("gstr3b_reported", 0) == 0:
            late_info = estimate_late_fee(financial_year, filing_frequency, period)
            notices.append(
                {
                    "priority": "High" if late_info["delay_days"] > 0 else "Medium",
                    "notice_type": "GSTR-3B Pending",
                    "message": (
                        f"GSTR-3B is not marked complete for {period}. "
                        f"Estimated late fee exposure as of today is Rs. {late_info['estimated_fee']:,.2f}."
                    ),
                    "recommended_action": "Validate liability and file GSTR-3B to avoid further delay exposure.",
                }
            )

        if row.get("itc_claimed", 0.0) > (row.get("output_tax", 0.0) * 0.85) and row.get("output_tax", 0.0) > 0:
            notices.append(
                {
                    "priority": "Medium",
                    "notice_type": "ITC Risk",
                    "message": f"ITC claimed for {period} is unusually high compared with output tax.",
                    "recommended_action": "Reconcile ITC with supplier invoices and GSTR-2A/2B support.",
                }
            )

    if not invoice_df.empty:
        duplicate_rows = invoice_df[invoice_df.duplicated(subset=["invoice_no"], keep=False)]
        if not duplicate_rows.empty:
            notices.append(
                {
                    "priority": "Medium",
                    "notice_type": "Duplicate Invoice Check",
                    "message": f"{len(duplicate_rows.index)} invoice row(s) have duplicate invoice numbers in the selected financial year.",
                    "recommended_action": "Review duplicates before final return generation.",
                }
            )
        missing_gstin_rows = invoice_df[invoice_df["counterparty_gstin"].fillna("").astype(str).str.strip().eq("")]
        if not missing_gstin_rows.empty:
            notices.append(
                {
                    "priority": "Low",
                    "notice_type": "Invoice Data Quality",
                    "message": f"{len(missing_gstin_rows.index)} invoice row(s) are missing counterparty GSTIN details.",
                    "recommended_action": "Fill missing GSTIN values to improve return quality and audit readiness.",
                }
            )

    return notices


def build_invoice_dataframe(rows):
    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame([dict(r) for r in rows])
    taxes = df.apply(
        lambda r: calculate_row_tax(r["taxable_value"], 0.0, r["gst_rate"], r["is_inter_state"]),
        axis=1,
        result_type="expand",
    )
    df = pd.concat([df, taxes], axis=1)
    return df


def get_gstr1_summary(invoice_df: pd.DataFrame):
    if invoice_df.empty:
        return {
            "invoice_count": 0,
            "taxable_value": 0.0,
            "output_tax": 0.0,
            "cgst": 0.0,
            "sgst": 0.0,
            "igst": 0.0,
        }

    return {
        "invoice_count": int(len(invoice_df.index)),
        "taxable_value": round(float(invoice_df["taxable_value"].sum()), 2),
        "output_tax": round(float(invoice_df["output_tax"].sum()), 2),
        "cgst": round(float(invoice_df["cgst"].sum()), 2),
        "sgst": round(float(invoice_df["sgst"].sum()), 2),
        "igst": round(float(invoice_df["igst"].sum()), 2),
    }


def get_gstr3b_summary(invoice_df: pd.DataFrame, credit_row: Optional[pd.Series] = None):
    gstr1 = get_gstr1_summary(invoice_df)
    credit_row = credit_row if credit_row is not None else {}

    itc_claimed = float(credit_row.get("itc_claimed", 0.0) or 0.0)
    tds_received = float(credit_row.get("tds_received", 0.0) or 0.0)
    tcs_received = float(credit_row.get("tcs_received", 0.0) or 0.0)

    net_payable = max(gstr1["output_tax"] - itc_claimed - tds_received - tcs_received, 0.0)

    return {
        "outward_taxable_supplies": gstr1["taxable_value"],
        "output_tax": gstr1["output_tax"],
        "cgst": gstr1["cgst"],
        "sgst": gstr1["sgst"],
        "igst": gstr1["igst"],
        "itc_claimed": round(itc_claimed, 2),
        "tds_received": round(tds_received, 2),
        "tcs_received": round(tcs_received, 2),
        "net_tax_payable": round(net_payable, 2),
    }


def build_auto_supporting_invoices(gstin: str, financial_year: str, period: str, credit_row: Optional[pd.Series] = None):
    credit_row = credit_row if credit_row is not None else {}
    generated = []

    if float(credit_row.get("itc_claimed", 0.0) or 0.0) > 0:
        generated.append(
            {
                "gstin": gstin,
                "financial_year": financial_year,
                "period": period,
                "invoice_no": f"ITC-{period.replace(' ', '').replace('(', '').replace(')', '').replace('/', '')}",
                "invoice_date": "2026-03-18",
                "doc_type": "System ITC Support",
                "counterparty_gstin": "SUPPORTGST0001Z5",
                "counterparty_name": "ITC Auto Support",
                "place_of_supply": "Auto",
                "taxable_value": float(credit_row.get("itc_claimed", 0.0) or 0.0),
                "gst_rate": 18.0,
                "is_inter_state": 0,
                "source_type": "Auto-ITC",
                "note": "System-generated supporting row from ITC claimed ledger.",
            }
        )

    if float(credit_row.get("tds_received", 0.0) or 0.0) > 0:
        generated.append(
            {
                "gstin": gstin,
                "financial_year": financial_year,
                "period": period,
                "invoice_no": f"TDS-{period.replace(' ', '').replace('(', '').replace(')', '').replace('/', '')}",
                "invoice_date": "2026-03-18",
                "doc_type": "System TDS Support",
                "counterparty_gstin": "SUPPORTGST0002Z5",
                "counterparty_name": "TDS Auto Support",
                "place_of_supply": "Auto",
                "taxable_value": float(credit_row.get("tds_received", 0.0) or 0.0),
                "gst_rate": 18.0,
                "is_inter_state": 0,
                "source_type": "Auto-TDS",
                "note": "System-generated supporting row from TDS credit ledger.",
            }
        )

    if float(credit_row.get("tcs_received", 0.0) or 0.0) > 0:
        generated.append(
            {
                "gstin": gstin,
                "financial_year": financial_year,
                "period": period,
                "invoice_no": f"TCS-{period.replace(' ', '').replace('(', '').replace(')', '').replace('/', '')}",
                "invoice_date": "2026-03-18",
                "doc_type": "System TCS Support",
                "counterparty_gstin": "SUPPORTGST0003Z5",
                "counterparty_name": "TCS Auto Support",
                "place_of_supply": "Auto",
                "taxable_value": float(credit_row.get("tcs_received", 0.0) or 0.0),
                "gst_rate": 18.0,
                "is_inter_state": 0,
                "source_type": "Auto-TCS",
                "note": "System-generated supporting row from TCS credit ledger.",
            }
        )

    return generated


def generate_otp():
    return str(randint(100000, 999999))


def generate_reference(prefix: str):
    return f"{prefix}{randint(10000000, 99999999)}"
