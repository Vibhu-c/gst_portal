# Smart GST & Compliance Management System Viva Guide

## Student Details
- Name: Vaibhav Srivastava
- Registration No.: 229303352
- College: Manipal University Jaipur
- Guide: Dr. Somya Goyal

## Project Introduction
My project is Smart GST & Compliance Management System. It is a web-based GST filing and compliance-support portal that helps a taxpayer manage company registration data, invoice entry, GSTR-1 preparation, GSTR-3B auto-population, tax liability review, filing acknowledgement, and compliance monitoring.

The goal of the project is not only GST calculation, but also smart compliance assistance.

## One-Minute Project Explanation
This system works like a GST portal-inspired platform. A user signs in, links their company, enters invoice data in GSTR-1, and the portal automatically prepares GSTR-3B using invoice values plus ITC, TDS, and TCS. It also generates compliance insights such as pending returns, invoice anomalies, due-date reminders, late-fee estimation, and next-tax forecasting. That is why it is called Smart GST & Compliance Management System.

## Why Is It Smart?
It is smart because it does more than manual filing. It automates return preparation, detects compliance risk, predicts future liability, estimates delay exposure, and gives recommendations before filing.

Main smart features:
- Automatic GST calculation
- Auto-population of GSTR-3B from GSTR-1 and credit ledger
- Compliance score generation
- Invoice anomaly detection
- Due-date and penalty estimation
- Smart notice center
- Next liability forecast
- Recommendation engine before filing

## Why Is It a Compliance Management System?
Because it manages not only GST data entry, but also filing discipline. It tracks whether GSTR-1, GSTR-3B, and GSTR-2A related records are complete, identifies missing invoice details, checks aggressive ITC usage, estimates late filing impact, and provides alerts and recommendations. So it manages compliance proactively.

## Technology Stack
### Frontend
- Streamlit
- Custom HTML/CSS inside Streamlit
- Plotly charts

### Backend
- Python
- SQLite database

## Libraries Used
### External libraries
- `streamlit`
- `pandas`
- `plotly`
- `reportlab`
- `yfinance`

### Built-in Python libraries
- `sqlite3`
- `datetime`
- `secrets`
- `urllib.parse`
- `io`
- `random`
- `typing`

## Why These Libraries Were Used
- `Streamlit`: for rapid web portal development
- `pandas`: for report tables, summaries, and analytics
- `Plotly`: for interactive graphs and visual dashboards
- `SQLite`: for lightweight local database storage
- `ReportLab`: for PDF acknowledgement generation
- `yfinance`: for public company integration
- `secrets`: for secure session tokens
- `datetime`: for dates, due dates, and timestamps
- `BytesIO`: for in-memory PDF generation

## Database Used
SQLite is used in this project. It is a lightweight file-based relational database. It does not need a separate server process. Python connects directly to the `.db` file using the `sqlite3` module.

## Why SQLite Instead of MySQL?
- Simpler for academic demonstration
- No database server installation required
- Easy local deployment
- Enough for a prototype and major project

For production, PostgreSQL or MySQL would be more suitable.

## Main Project Modules
- User Authentication
- Taxpayer Master
- Public Company API Integration
- GSTR-1 Invoice Entry
- Credit Ledger
- GSTR-3B Auto-Population
- Filing and Payment
- Acknowledgement Generation
- Smart Insights
- GSTN Integration Readiness

## System Workflow
1. User signs in
2. User links their own company
3. User selects monthly or quarterly filing
4. User enters invoice data in GSTR-1
5. System validates invoice data
6. GSTR-3B auto-populates
7. User reviews liability, ITC, TDS, and TCS
8. OTP and payment flow runs
9. Filing acknowledgement PDF is generated
10. Smart compliance module shows score, risks, and recommendations

## How GSTR-1 and GSTR-3B Are Connected
GSTR-1 stores invoice-based outward supply details. The system calculates taxable value and output tax from these invoices. Then GSTR-3B uses that invoice summary and combines it with ITC, TDS, and TCS to compute final tax liability automatically.

## Security Features
- User authentication
- Hashed passwords
- Session-based login
- GSTIN validation
- Linked company-based filing control

## Validation Features
- GSTIN format validation
- GSTIN checksum validation
- Invoice entry validation
- Company type logic
- Public-company ticker requirement only when needed
- Filing-step validation
- Digital-signature style confirmation

## Important Source Files
- `app.py`: Main UI, workflow, routing, filing process
- `db.py`: Database schema, insert/update/query logic
- `gst_engine.py`: GST computation, smart analytics, due dates, notices
- `company_api.py`: Public company data integration
- `validators.py`: GSTIN validation logic
- `auth.py`: Password hashing and verification
- `demo_data.py`: Demo seed data

## What Is in Each File?
### `app.py`
Main entry point. Controls the Streamlit UI, page navigation, forms, filing workflow, and integration of all other modules.

### `db.py`
Handles database creation, tables, user data, company data, GST records, filing events, and session storage.

### `gst_engine.py`
Contains GST calculations, return summaries, compliance score logic, notice generation, due-date tracking, and forecasting.

### `validators.py`
Validates GSTIN format and checksum.

### `company_api.py`
Fetches public company information and fallback demo data.

### `auth.py`
Handles password hashing and verification.

## Tables in Database
- `users`
- `companies`
- `gst_entries`
- `invoice_entries`
- `filing_events`
- `auth_sessions`

## Real vs Simulated Parts
### Realistic parts
- Login flow
- Company master management
- GSTIN validation
- Invoice-based filing
- GSTR-3B auto-population
- Compliance score and analytics
- PDF acknowledgement generation

### Simulated parts
- OTP delivery
- Challan/payment banking flow
- Government GSTN filing confirmation

Real GSTN production integration requires official GSP/ASP or government-approved onboarding.

## AIML Professor Answer
This project is not a deep machine learning production model, but it includes AI-style intelligent features. It uses rule-based analytics, risk scoring, anomaly detection, forecasting logic, and recommendation generation to support compliance decisions. So it acts as a decision-support system.

If asked whether this is true AI:
Yes, it is an intelligent analytics system more than a full ML system. It is designed practically for compliance support. In future it can be extended into ML-based fraud detection, mismatch prediction, and taxpayer risk classification.

## Future AI/ML Scope
- Invoice anomaly detection model
- Fraud-risk prediction
- Late-filing prediction
- Taxpayer clustering
- ITC mismatch prediction
- NLP-based GST help assistant
- Smart chatbot for compliance support

## Public Company API Use
Public company data is used to make the portal more realistic. For public/listed entities, turnover-related business context can be fetched using public financial APIs. This improves demo realism.

## Why Real Government API Is Not Fully Integrated
Real GST filing integration is not an open public API like a normal web API. Production filing requires official onboarding through GSTN-authorized channels such as GSP or ASP integration. Therefore, the academic project keeps this part realistic but simulated.

## Strong Viva Line for Smart Features
This portal is smart because it not only files GST data, but also monitors compliance health, detects invoice risks, predicts future liability, estimates delay penalties, drafts compliance notices, and recommends corrective action before filing.

## Common Viva Questions and Answers
### Q. What problem does your project solve?
It simplifies GST return preparation and improves compliance monitoring by combining filing workflow, tax calculation, invoice handling, and smart alerts in one portal.

### Q. Why did you choose this topic?
GST compliance is important for businesses, but the process is still complex for many users. I wanted to build a system that reduces manual work and improves compliance quality.

### Q. What makes your project different from a normal GST calculator?
A normal calculator only computes tax. My project also manages filing workflow, invoice handling, return linkage, compliance scoring, due-date tracking, and risk recommendations.

### Q. How is GSTR-3B auto-populated?
It is computed from GSTR-1 invoice data and adjusted using credit ledger values like ITC, TDS, and TCS.

### Q. What is your innovation?
The innovation is the smart compliance layer: compliance score, invoice anomaly review, notice generation, liability forecasting, and pre-filing recommendations.

### Q. Is this deployable in the real world?
As a prototype, yes. For real-world production use, it would need official GSTN integration, stronger security, cloud deployment, audit logs, and an enterprise database.

### Q. What are the limitations?
Real OTP/SMS and real GSTN filing need official integration. SQLite is local only. Current prediction is rule-based, not advanced ML-based.

### Q. What is the future scope?
ML-based fraud detection, GST mismatch prediction, chatbot assistance, bank integration, real SMS OTP, and official GSTN onboarding.

### Q. Why did you use Streamlit?
It helped rapidly build a working web portal in Python with forms, tables, dashboards, and quick prototyping for a complete academic demonstration.

### Q. How are passwords stored?
Passwords are stored in hashed form, not plain text.

### Q. What is the role of SQLite here?
It stores users, companies, GST entries, invoices, filing events, and sessions locally.

### Q. Which libraries have you used?
I used Streamlit for frontend, pandas for data processing, Plotly for charts, sqlite3 for the database, ReportLab for PDF generation, yfinance for public company data, and standard Python libraries like datetime, secrets, urllib, io, random, and typing for application logic.

### Q. Which are built-in and which are external libraries?
Built-in libraries are `sqlite3`, `datetime`, `secrets`, `urllib.parse`, `io`, `random`, and `typing`. External libraries are `streamlit`, `pandas`, `plotly`, `reportlab`, and `yfinance`.

### Q. Why did you separate the code into multiple files?
To keep the project modular, maintainable, and easier to explain. Each file has a separate responsibility like UI, database, validation, API integration, or GST logic.

### Q. Why are passwords hashed?
For security. Plain-text passwords are unsafe. Hashing protects stored credentials.

### Q. How is session handled?
After login, a secure token is generated and stored. That token is used to maintain login state and allow navigation across pages.

### Q. How does the app validate GSTIN?
It checks GSTIN format using pattern validation and checksum logic before accepting taxpayer data.

### Q. How do you generate the acknowledgement PDF?
Using ReportLab. The data is formatted and written into a structured PDF layout in memory using `BytesIO`, then downloaded through Streamlit.

### Q. Why is `BytesIO` used?
It helps generate the PDF in memory without needing a temporary file on disk.

### Q. Why use `secrets` instead of random for sessions?
Because session tokens should be generated securely. `secrets` is better for security-sensitive token generation.

## Best Closing Answer
This project demonstrates how GST filing can be combined with smart compliance support. Instead of only generating tax, it helps taxpayers prepare returns, review liability, detect risks, and improve compliance quality. That is the main value of the Smart GST & Compliance Management System.
